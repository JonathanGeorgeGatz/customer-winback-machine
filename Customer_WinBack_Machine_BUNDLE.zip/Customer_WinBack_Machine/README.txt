THE CUSTOMER WIN-BACK MACHINE — reference
From "Build It With AI" — Episode 8.

Setup is in START_HERE.txt. This file is what everything means.

==============================================================================
HOW A CUSTOMER IS JUDGED
==============================================================================

A customer is an email address, lowercased and trimmed. Capitalisation and
stray spaces are not identity — tills migrate, tablets change, the woman is
the same woman. Two rows on the same day are one visit.

Their USUAL GAP is the median of the day-counts between their consecutive
visits (with an even number of gaps, the average of the middle two).

"Today" is the NEWEST DATE IN YOUR EXPORT, printed on the report as
"as of". A file you exported in June must not make everyone look lapsed
in September.

A YEAR OF THEM = total spend x 365 / their tenure in days, where tenure is
first visit to last visit plus one usual gap, never less than 365. A
two-year, $2,040 customer is about $1,020 a year; a brand-new customer's
first $85 stays $85. It is a yearly rate, not a lifetime number, and the
report says "a year of them" so nobody mistakes one for the other.

==============================================================================
THE SETTINGS
==============================================================================

setting                      default   what it does
------------------------------------------------------------------------------
lapsed past (x usual gap)    2.5       Gone quiet once their silence passes
                                       this multiple of their own usual gap
                                       (never less than 30 days).
slipping past (x usual gap)  1.5       Overdue but not gone (never less than
                                       14 days). The list to act on first.
visits before cadence counts 3         Fewer visits than this and the tool
                                       refuses to claim it knows a rhythm.
one-timer quiet days         90        One visit, quiet past this -> NEVER
                                       CAME BACK. Newer -> too new to chase.
assumed win-back rate %      10        Only feeds the projection card. The
                                       card says "estimate" because it is.

Every setting was tested to confirm it moves the output on the sample data.
A setting that cannot change the answer is decoration, and an earlier
episode of this series shipped exactly that bug — so now it is a test.

==============================================================================
THE LISTS
==============================================================================

GONE QUIET       Regulars (3+ visits) silent past 2.5x their own gap.
                 Ranked by a-year-of-them, biggest first, because you
                 cannot chase everyone and should not try.
SLIPPING         Past 1.5x their gap but not lapsed yet. A message lands
                 best here — they have not fully left.
NEVER CAME BACK  One visit, then silence past the one-timer window. They
                 never started a habit, so the "we miss you" framing is
                 wrong for them; the generator adjusts.
TOO NEW TO CALL  Not enough visits for a rhythm, or a recent first-timer.
                 No verdict, on purpose.
ROWS IT REFUSED  Every line it could not use — no email, unreadable date,
                 negative refund line — with the row number and reason.
                 A report should say what it is not built on.

==============================================================================
THE THREE MESSAGES
==============================================================================

A — the offer. Warm, short, one concrete incentive. The [YOUR OFFER]
    placeholder is deliberately not filled in: the right offer is a
    judgement about your margins, not a template's.
B — the check-in. No discount. For the customer you suspect drifted, where
    a coupon would cheapen it.
C — the ask. For when something may have gone wrong. It invites the reply
    you least want and most need.

All three merge the customer's first name, their last service, and their
own rhythm ("you used to come in about every 4 weeks"). Nothing sends
automatically. You read it, you fix it, you send it from your own email.

==============================================================================
CHECKING MY WORK
==============================================================================

independent_checker.py is a second implementation of the same rules in
Python, built a deliberately different way (three passes over the data
instead of streaming). Run it on the same CSV:

    python3 independent_checker.py sample_export.csv

The two were compared across 26 settings combinations and 40,248 fields
before this shipped, with zero disagreements. engine_v1.js is the FIRST
build, kept so you can see both wrong turns the video shows — raw-string
identity and the lifetime-spend "value" — plus the 90-day rule that both
implementations agreed on while both were wrong.

==============================================================================
WHAT THIS DOES NOT DO
==============================================================================

It does not send email, sync with anything, measure open rates, or run
drip sequences — if you have an online store and a big list, that is what
Klaviyo and Mailchimp are for, and they are good at it. It does not know
WHY anyone left. It reads one export, tells you who went quiet against
their own habit, what a year of them is worth, and what to say. The
deciding and the sending are yours.
