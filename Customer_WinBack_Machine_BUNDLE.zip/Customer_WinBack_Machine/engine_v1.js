/* CUSTOMER WIN-BACK MACHINE — v1 engine (first build, from PROMPT_1).
   Kept for the record: this is the version with the wrong turns in it.
   - identity is the RAW email string ("Mika@…" and "mika@…" are two people)
   - lapsed means "no visit in 90 days", for everyone, regardless of cadence
   - a customer's value is their LIFETIME spend, reported as yearly-sounding
*/

var V1_LAPSE_DAYS = 90;

function v1parseDate(s) {
  if (s === null || s === undefined) return null;
  s = String(s).trim();
  var m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) {
    var d = Date.UTC(+m[1], +m[2] - 1, +m[3]);
    var chk = new Date(d);
    if (chk.getUTCFullYear() !== +m[1] || chk.getUTCMonth() !== +m[2] - 1 || chk.getUTCDate() !== +m[3]) return null;
    return Math.round(d / 86400000);
  }
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    var d2 = Date.UTC(+m[3], +m[1] - 1, +m[2]);
    var chk2 = new Date(d2);
    if (chk2.getUTCFullYear() !== +m[3] || chk2.getUTCMonth() !== +m[1] - 1 || chk2.getUTCDate() !== +m[2]) return null;
    return Math.round(d2 / 86400000);
  }
  return null;
}

function v1parseCSV(text) {
  var out = [], row = [], cur = "", inQ = false;
  for (var i = 0; i < text.length; i++) {
    var ch = text[i];
    if (inQ) {
      if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else inQ = false; }
      else cur += ch;
    } else if (ch === '"') inQ = true;
    else if (ch === ",") { row.push(cur); cur = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(cur); cur = "";
      if (row.length > 1 || row[0] !== "") out.push(row);
      row = [];
    } else cur += ch;
  }
  row.push(cur);
  if (row.length > 1 || row[0] !== "") out.push(row);
  return out;
}

function v1build(csvText) {
  var rows = v1parseCSV(csvText);
  if (rows.length && /date/i.test(rows[0][0])) rows = rows.slice(1);

  var customers = {};
  var asOf = null;
  rows.forEach(function (r) {
    var day = v1parseDate(r[0]);
    var email = r[2] === undefined ? "" : String(r[2]);
    var amount = parseFloat(String(r[4] === undefined ? "" : r[4]).replace(/[$,]/g, ""));
    if (day === null || isNaN(amount)) return;          // quietly skip
    if (asOf === null || day > asOf) asOf = day;
    var c = customers[email] = customers[email] || {
      name: r[1], email: email, visits: 0, total: 0, last: null, lastService: ""
    };
    c.visits++;
    c.total += amount;
    if (c.last === null || day >= c.last) { c.last = day; c.name = r[1]; c.lastService = r[3]; }
  });

  var all = Object.keys(customers).map(function (k) { return customers[k]; });
  all.forEach(function (c) {
    c.daysQuiet = asOf - c.last;
    c.total = Math.round(c.total * 100) / 100;
    c.lapsed = c.daysQuiet > V1_LAPSE_DAYS;
  });

  var lapsed = all.filter(function (c) { return c.lapsed; });
  lapsed.sort(function (a, b) { return b.total - a.total || (a.email < b.email ? -1 : 1); });

  var lapsedValue = 0;
  lapsed.forEach(function (c) { lapsedValue += c.total; });

  return {
    asOf: asOf,
    customers: all,
    lapsed: lapsed,
    totals: {
      customerCount: all.length,
      lapsedCount: lapsed.length,
      lapsedValue: Math.round(lapsedValue * 100) / 100
    }
  };
}

if (typeof module !== "undefined") {
  module.exports = { v1build: v1build, v1parseDate: v1parseDate, v1parseCSV: v1parseCSV };
}
