#!/usr/bin/env python3
"""INDEPENDENT REFERENCE — Customer Win-Back Machine.

Deliberately a different construction from the JavaScript engine, not a
translation: the engine builds per-customer records as it streams rows; this
one makes three full passes (clean the rows, build calendars, then judge),
and derives every threshold from a small Rule table. Written from the three
prompts only.

Usage: reference.py <export.csv> [overrides.json]
"""
import csv, json, sys, datetime as dt
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP

DEFAULTS = {
    "lapse_multiplier": 2.5,
    "slipping_multiplier": 1.5,
    "min_visits": 3,
    "one_time_quiet_days": 90,
    "winback_rate_pct": 10,
}
LAPSE_FLOOR = 30
SLIP_FLOOR = 14
EPOCH = dt.date(1970, 1, 1)


def money(x):
    """Half away from zero, like the till expects."""
    return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def parse_date(s):
    s = str(s or "").strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y"):
        try:
            d = dt.datetime.strptime(s, fmt).date()
            return (d - EPOCH).days
        except ValueError:
            continue
    return None


def day_iso(n):
    return (EPOCH + dt.timedelta(days=n)).isoformat()


def median(xs):
    a = sorted(xs)
    n = len(a)
    if not n:
        return None
    return a[(n - 1) // 2] if n % 2 else (a[n // 2 - 1] + a[n // 2]) / 2


def build(csv_text, overrides=None):
    S = dict(DEFAULTS)
    if overrides:
        for k, v in overrides.items():
            if k in S and v is not None and v != "":
                S[k] = float(v)

    reader = list(csv.reader(csv_text.splitlines()))
    start_line = 1
    if reader and "date" in str(reader[0][0]).lower():
        reader = reader[1:]
        start_line = 2

    # pass 1 — clean the rows
    clean, unusable = [], []
    for i, r in enumerate(reader):
        line = i + start_line
        r = list(r) + [""] * (5 - len(r))
        day = parse_date(r[0])
        if day is None:
            unusable.append({"row": line, "reason": f'unreadable date: "{str(r[0]).strip()}"'})
            continue
        key = str(r[2]).strip().lower()
        if not key:
            unusable.append({"row": line, "reason": "no email — cannot identify the customer"})
            continue
        amt_s = str(r[4]).replace("$", "").replace(",", "").replace(" ", "").replace("\t", "")
        try:
            amount = float(amt_s)
        except ValueError:
            unusable.append({"row": line, "reason": f'unreadable amount: "{str(r[4]).strip()}"'})
            continue
        if amount < 0:
            unusable.append({"row": line, "reason": "negative amount (refund line) — handle refunds upstream"})
            continue
        clean.append({"line": line, "day": day, "name": str(r[1]).strip(),
                      "key": key, "service": str(r[3]).strip(), "amount": amount})

    as_of = max((r["day"] for r in clean), default=None)

    # pass 2 — calendars
    cal = defaultdict(lambda: {"days": defaultdict(float), "total": 0.0,
                               "name": "", "service": "", "last_seen": -1})
    for r in clean:
        c = cal[r["key"]]
        c["days"][r["day"]] += r["amount"]          # same-day rows are one visit
        c["total"] += r["amount"]
        if r["day"] >= c["last_seen"]:
            c["last_seen"] = r["day"]
            c["name"] = r["name"]
            c["service"] = r["service"]

    # pass 3 — judge each customer against their own rhythm
    customers = {}
    for key, c in cal.items():
        days = sorted(c["days"])
        gaps = [b - a for a, b in zip(days, days[1:])]
        med = median(gaps) if len(days) >= S["min_visits"] else None
        first, last = days[0], days[-1]
        quiet = as_of - last
        tenure = (last - first) + (med if med is not None else 0)
        annual = money(c["total"] * 365 / max(tenure, 365))

        threshold = None
        if len(days) == 1:
            segment = "ONE_TIME" if quiet > S["one_time_quiet_days"] else "LOW_DATA"
            threshold = S["one_time_quiet_days"]
        elif med is None:
            segment = "LOW_DATA"
        else:
            lapse_at = max(S["lapse_multiplier"] * med, LAPSE_FLOOR)
            slip_at = max(S["slipping_multiplier"] * med, SLIP_FLOOR)
            threshold = lapse_at
            if quiet > lapse_at:
                segment = "LAPSED"
            elif quiet > slip_at:
                segment = "SLIPPING"
            else:
                segment = "ACTIVE"

        customers[key] = {
            "name": c["name"], "email": key, "visits": len(days),
            "firstDate": day_iso(first), "lastDate": day_iso(last),
            "totalSpend": money(c["total"]), "medianGap": med,
            "daysQuiet": quiet, "annualValue": annual, "segment": segment,
            "thresholdDays": None if threshold is None else round(threshold * 100) / 100,
        }

    def ranked(seg):
        return [k for k, v in sorted(customers.items(),
                                     key=lambda kv: (-kv[1]["annualValue"], kv[0]))
                if v["segment"] == seg]

    segments = {s: ranked(s) for s in ("LAPSED", "SLIPPING", "ONE_TIME", "LOW_DATA", "ACTIVE")}
    lapsed_annual = money(sum(customers[k]["annualValue"] for k in segments["LAPSED"]))
    slip_annual = money(sum(customers[k]["annualValue"] for k in segments["SLIPPING"]))
    one_time_spend = money(sum(customers[k]["totalSpend"] for k in segments["ONE_TIME"]))

    return {
        "asOf": None if as_of is None else day_iso(as_of),
        "customers": customers,
        "segments": segments,
        "totals": {
            "customerCount": len(customers),
            "rowsUsed": len(clean),
            "lapsedCount": len(segments["LAPSED"]),
            "lapsedAnnualValue": lapsed_annual,
            "slippingCount": len(segments["SLIPPING"]),
            "slippingAnnualValue": slip_annual,
            "oneTimeCount": len(segments["ONE_TIME"]),
            "oneTimeSpend": one_time_spend,
            "activeCount": len(segments["ACTIVE"]),
            "lowDataCount": len(segments["LOW_DATA"]),
            "projectedRecovery": money(lapsed_annual * S["winback_rate_pct"] / 100),
        },
        "unusable": unusable,
        "settings": S,
    }


if __name__ == "__main__":
    text = open(sys.argv[1]).read()
    overrides = json.load(open(sys.argv[2])) if len(sys.argv) > 2 else None
    print(json.dumps(build(text, overrides), indent=1))
